package engine;
//package com.example.gameengine;
// imageview positions are leftcorner anchors

import javafx.scene.image.ImageView;

import java.util.ArrayList;

/**
 * Name: Jiaming Liu
 * Period: 2
 **/

//abstract class World { // placeholder
//    abstract  <A extends Actor> java.util.List<A> getObjects(java.lang.Class<A> cls);
//}

public abstract class Actor extends ImageView {
	
    public World getWorld() {
        return (World)getParent();
    }

    public void addedToWorld() {};
    
    public void move(double dx, double dy) {
        setX(getX() + dx);
        setY(getY() + dy);
    }

    public double getWidth(){
        return getBoundsInParent().getWidth();
    }

    public double getHeight() {
        return getBoundsInParent().getHeight();
    }

    public <A extends Actor> java.util.List<A> getIntersectingObjects(java.lang.Class<A> cls){
        ArrayList<A> res = new ArrayList<>();
        for (A actor: getWorld().getObjects(cls)){
            if (!this.equals(actor) && isOverlapping(this, actor)){
                res.add(actor);
            }
        }
        return res;
    }

    public <A extends Actor> A getOneIntersectingObject(java.lang.Class<A> cls){
        for (A actor: getWorld().getObjects(cls)){
            if (!this.equals(actor) && isOverlapping(this, actor)){
                return actor;
            }
        }
        return null;
    }

    public abstract void act(long now);

    private static boolean isOverlapping(Actor a1, Actor a2){
        return (isOverlappingX(a1, a2) && isOverlappingY(a1, a2)) ? true : false; 
    }

	private static boolean isOverlappingY(Actor a1, Actor a2) {
		//a1 top edge between a2 edges
		if (a1.getY() >= a2.getY() && a1.getY() <= a2.getY() + a2.getHeight()) return true;
		//a2 top edge between a1 edges
		if (a2.getY() >= a1.getY() && a2.getY() <= a1.getY() + a1.getHeight()) return true;
		
		return false;
	}

	private static boolean isOverlappingX(Actor a1, Actor a2) {
		//a1 left edge between a2 edges
		if (a1.getX() >= a2.getX() && a1.getX() <= a2.getX() + a2.getWidth()) return true;
		//a2 left edge between a1 edges
		if (a2.getX() >= a1.getX() && a2.getX() <= a1.getX() + a1.getWidth()) return true;

		return false;
	}
}
