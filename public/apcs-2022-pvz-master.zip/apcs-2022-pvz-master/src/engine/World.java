package engine;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import javafx.animation.AnimationTimer;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;

public abstract class World extends Pane {
	//getChildren() is getActors()	
	
	private AnimationTimer timer;
	private HashSet<KeyCode> keysPressed;
	private boolean started;
	private boolean widthSet, heightSet;
	private boolean initialized;
	
	public World() {
		timer = new MyTimer();
		keysPressed = new HashSet<>();
		started = false;
		widthSet = false;
		heightSet = false;
		initialized = false;
		widthProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> arg0, Number arg1, Number arg2) {
				widthSet = true;
				if(widthSet && heightSet && !initialized) {
					onDimensionsInitialized();
					initialized = true;
				}
			}
		});
		heightProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> arg0, Number arg1, Number arg2) {
				heightSet = true;
				if(widthSet && heightSet && !initialized) {
					onDimensionsInitialized();
					initialized = true;
				}
			}
		});
		sceneProperty().addListener(new ChangeListener<Scene>() {
			@Override
			public void changed(ObservableValue<? extends Scene> curScene, Scene oldScene, Scene newScene) {
				if (newScene != null) {
					requestFocus();
				}
			}
		});
		setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent e) {
				addKey(e.getCode());
			}
		});
		setOnKeyReleased(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent e) {
				removeKey(e.getCode());
			}
		});
	}
	
	private class MyTimer extends AnimationTimer {
		@Override
		public void handle(long now) {
			act(now);
			Iterator<Actor> iter = getActors().iterator();
			while(iter.hasNext()) {
				Actor actor = iter.next();
				if(!(actor == null) && !(actor.getWorld() == null)) {
					actor.act(now);
				}
			}
		}
	}
	
	public void start() {
		timer.start();
		started = true;
	}
	
	public void stop() {
		timer.stop();
		started = false;
	}
	
	public void add(Actor actor) {
		getChildren().add(actor);
		actor.addedToWorld();
	}
	
	public void remove(Actor actor) {
		getChildren().remove(actor);
	}
	
	public void addKey(KeyCode kc) {
		keysPressed.add(kc);
	}
	
	public void removeKey(KeyCode kc) {
		keysPressed.remove(kc);
	}
	
	public boolean isKeyPressed(KeyCode kc) {
		return keysPressed.contains(kc);
	}
	
	public ArrayList<Actor> getActors(){
		ArrayList<Actor> actors = new ArrayList<>();
		for(Node actor : getChildren()) {
			if((Actor.class).isAssignableFrom(actor.getClass())) {
				actors.add((Actor) actor);
			}
		}
		return actors;
	}
	
	public <A extends Actor> java.util.List<A> getObjects(java.lang.Class<A> cls) {
		ArrayList<A> list = new ArrayList<>();
		for(Node actor : getChildren()) {
			if(cls.isInstance(actor)) {
				list.add((A) actor);
			}
		}
		return list;
	}
	
	// x needs to be between actor's left edge and right edge
	// y needs to be between actor's top edge and bottom edge
	public <A extends Actor> java.util.List<A> getObjectsAt(double x, double y, java.lang.Class<A> cls){
		ArrayList<A> list = new ArrayList<>();
		for(Actor actor: getObjects(cls)){
			if (actor.getX() - actor.getWidth()/2 <= x && x <= actor.getX() + actor.getWidth() && actor.getY() <= y && y <= actor.getY() + actor.getHeight()){
				list.add((A)actor);
			}
		}
		return list;
	}
	
	public abstract void act(long now);
	
	public abstract void onDimensionsInitialized();
	
	public boolean isStopped() {
		return !started;
	}
}
