/**
 * Name: Jiaming Liu
 * Period: 2
 **/

import engine.Actor;
import javafx.scene.image.Image;

public class Pea extends Actor {
    private Audio shootSound = new Audio("resources/music/pea.wav");
    private Audio hitSound = new Audio("resources/music/hit.wav");
    private int dx = 4;
    private int damage = 35;

    public Pea() {
        setImage(new Image("resources/pea.png"));
        setPreserveRatio(true);
        setFitWidth(16);
        shootSound.play();
    }

    @Override
    public void act(long now) {
        move(dx, 0);
        if (getOneIntersectingObject(Zombie.class) != null){
            Zombie z = getOneIntersectingObject(Zombie.class);
            z.takeDamage(damage);
            hitSound.play();
            getWorld().remove(this);
        }
    }
}