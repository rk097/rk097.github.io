import javafx.scene.image.Image;

/**
 * Name: Jiaming Liu
 * Period: 2
 **/

public class Peashooter extends Plant {
    public Peashooter() {
        health = 600;
        price = 100;
        actionCooldown = 1.5 * NANO_CONSTANT;
        setImage(new Image("resources/peashooter.gif"));
        setPreserveRatio(true);
        setFitWidth(80);
    }

    @Override
    public void act(long now) {	
        if ((now-oldTime) >= actionCooldown) {
        	shoot();
            oldTime = now;
        }
    }
    
    private void shoot(){
    	if(level.getZombiesInRow(row).size() == 0) return;
        Pea pea = new Pea();
        pea.setX(getX()+pea.getWidth()*2);
        pea.setY(getY()+pea.getHeight()*2);
        getWorld().add(pea);
    }

}
