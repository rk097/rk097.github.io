public class HardLevel extends Level {

    public HardLevel(Game game) {
        super(game);
    }

    @Override
    public void onDimensionsInitialized(){
        super.onDimensionsInitialized();
        GAME.getHUD().initializeDeck(PlantCard.PEASHOOTER, PlantCard.SUNFLOWER);
    }

    @Override
    void addZombies() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < Math.random() * 15; j++) {
                Zombie z;
                double possibility = Math.random();
                if (possibility < 0.4) z = new BasicZombie(Math.random() * 60);
                else if (possibility < 0.7) z = new ConeZombie(20 + Math.random() * 40);
                else if (possibility < 0.9) z = new BucketHeadZombie(30 + Math.random() * 30);
                else z = new FlagZombie(50.0);
                addZombie(i, z);
                z.setX(getWidth() + getWidth() * 10 * Math.random());
            }
        }
    }
}
