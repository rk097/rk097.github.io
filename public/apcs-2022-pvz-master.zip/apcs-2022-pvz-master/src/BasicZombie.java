import javafx.scene.image.Image;

public class BasicZombie extends Zombie {
	public BasicZombie(double enterDelay) {
		super(enterDelay);
		health = 181;
        attackDamage = 100;
        defaultSprite = new Image("resources/zombie.gif");
        setImage(defaultSprite);
	}
}
