
interface SunListener {
	public void onSunAmountChanged(int newSunAmount);
}
