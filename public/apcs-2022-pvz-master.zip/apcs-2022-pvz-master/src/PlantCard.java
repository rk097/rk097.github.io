import java.io.FileInputStream;
import java.io.FileNotFoundException;

import engine.Actor;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

public class PlantCard extends Actor {
	
	private String plantSpecies;
	private CardDeck parentDeck;
	private PlantCard self = this;
    final static PlantCard PEASHOOTER = new PlantCard("peashooterCard.jpg");
    final static PlantCard SUNFLOWER = new PlantCard("sunflowerCard.jpg");

    private PlantCard(String imgPath) {
    	this.plantSpecies = imgPath;
        Image img;
        try {
            img = new Image(new FileInputStream("resources/" + imgPath));
            setImage(img);
            setFitHeight(80);
            setPreserveRatio(true);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
        this.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent e) {
				if(e.getButton() == MouseButton.PRIMARY) {
					// theoretically impossible but its a failsafe for the future just in case i forget
					if(parentDeck == null) throw new NullPointerException("This card has no parent for some reason");
					
					parentDeck.onCardSelected(self);
				}
			}
        	
        });
    }

    @Override
    public void act(long now) {

    }
    
    public Plant asPlant() {
    	if(plantSpecies.equals("peashooterCard.jpg")) {
    		return new Peashooter();
    	} else if (plantSpecies.equals("sunflowerCard.jpg")) {
    		return new Sunflower();
    	}
    	return null;
    }
    
    public void setDeck(CardDeck p) {
    	parentDeck = p;
    }
    
}
