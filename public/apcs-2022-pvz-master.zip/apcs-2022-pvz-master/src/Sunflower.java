import java.util.Random;

import javafx.scene.image.Image;

public class Sunflower extends Plant {

	public Sunflower() {
		health = 500;
		price = 50;
		actionCooldown = 6 * NANO_CONSTANT; // normally 24 but nerfed for testing
        setImage(new Image("resources/sunflower.gif"));
        setPreserveRatio(true);
        setFitWidth(80);
	}
	
	@Override
	public void act(long now) {
		if ((now-oldTime) >= actionCooldown) {
        	produceSun();
            oldTime = now;
        }
	}

	private void produceSun() {
		Random r = new Random();
		Sun sun = new Sun();
		sun.setX(getX()+(r.nextInt((int)getWidth())*.5-getWidth()/4));
        sun.setY(getY()+(r.nextInt((int)getHeight())*.5-getHeight()/4));
        getWorld().add(sun);
	}
}
