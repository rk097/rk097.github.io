import javafx.scene.image.Image;

public class FlagZombie extends Zombie {
    public FlagZombie(double enterDelay) {
    	super(enterDelay);
        health = 181;
        attackDamage = 100;
        defaultSprite = new Image("resources/flagZombie.gif");
        setImage(defaultSprite);
    }
}
