import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

// implements
// please refrain from calling getChildren() of this class directly

public class CardDeck extends HBox implements SunListener, SelectedCardListener {
    
    private Label sunLabel;
    private int selectedIndex;
    
    public CardDeck() {
    	selectedIndex = -1;
        setPadding(new Insets(5, 0, 0, 0));
        sunLabel = new Label();
        sunLabel.setText("  0");
        sunLabel.setFont(Font.font("Verdana", FontWeight.BOLD, 18));
        sunLabel.setPadding(new Insets(59, 32, 0, 24));
        getChildren().add(sunLabel);
        BackgroundImage myBI = null;
        try {
            myBI = new BackgroundImage(new Image(new FileInputStream("resources/CardDeck.png"),480,90,false,true), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        setBackground(new Background(myBI));
    }
   
    public void setSun(int newSun){
        if ((newSun + "").length() == 1)
            sunLabel.setText("  " + newSun);
        else if ((newSun + "").length() == 2)
            sunLabel.setText(" " + newSun);
        else
            sunLabel.setText(newSun + "");
    }

    public int getSun(){
        return Integer.parseInt(sunLabel.getText());
    }

    @Override
    public void onSunAmountChanged(int newSunAmount) {
        setSun(newSunAmount);
    }
    
    private void reset() {
    	getChildren().removeAll(getChildrenCards());
    }
    
	public Plant getSelectedCardAsPlant() {
		if(selectedIndex == -1) return null;
		return ((PlantCard)(getChildren().get(selectedIndex))).asPlant();
	}

	@Override
	public void onCardSelected(PlantCard p) {
		if(p == null) {
			selectedIndex = -1;
			return;
		}
		
		int i = 0;
		for(Node a : getChildren()) {
			if(a == p) {
				
				//if the plant in question already selected, deselect
				if(selectedIndex == i) {
					selectedIndex = -1;
					return;
				}
				
				selectedIndex = i;
				break;
			}
			i++;
		}
	}
	
	// call on every new level
	public void initializeDeck(PlantCard... cards) {
		reset();
		getChildren().addAll(cards);
		for(PlantCard p : cards) {
			p.setDeck(this);
		}
	}
	
	private ArrayList<PlantCard> getChildrenCards() {
		ArrayList<PlantCard> al = new ArrayList<>();
		for(Node n : getChildren()) {
			if(n.getClass() == PlantCard.class) {
				al.add((PlantCard) n);
			}
		}
		return al;
	}
	
	public void remove() {
		this.setOpacity(0);
	}
}