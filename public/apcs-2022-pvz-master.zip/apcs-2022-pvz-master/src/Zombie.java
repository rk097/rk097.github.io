/**
 * Name: Jiaming Liu
 * Period: 2
 **/

public abstract class Zombie extends NPC {
	
	// for zombies, actionCooldown represents delay between attack
	
	private int MOTION_CONSTANT = 1;
    protected int attackDamage;
    protected double secondsPerTile, motionCooldown; // movement delay, in seconds.
    
    protected double enterDelay;
    private boolean entered, init; // init is for time purposes...

    private Audio eatPlantSound = new Audio("resources/music/eatPlant.wav");

    public Zombie(double enterDelay) {
    	entered = false;
    	init = false;
    	this.enterDelay = enterDelay * NANO_CONSTANT;
        actionCooldown = 0.5 * NANO_CONSTANT;
        secondsPerTile = 4.7;
        setPreserveRatio(true);
        setFitWidth(70);
    }

    @Override
    public void act(long now) {
    	if (!entered) {
    		if(!init) {
    			init = true;
    			oldTime = now;
    		}
    		if((now-oldTime) >= enterDelay) {
    			entered = true;
    		}
    	}
    	else if(getOneIntersectingObject(Plant.class) != null && getOneIntersectingObject(Plant.class).getRow() == row) {
    		if ((now-oldTime) >= actionCooldown) {
    			getOneIntersectingObject(Plant.class).takeDamage(attackDamage);
                oldTime = now;
    		}
            if (!eatPlantSound.status.equals("play")) {
                eatPlantSound.enableLoop();
                eatPlantSound.play();
            }
    	}
    	else if ((now-oldTime) >= motionCooldown) {
        	move(-MOTION_CONSTANT, 0);
            oldTime = now;
            if (eatPlantSound.status.equals("play")) eatPlantSound.pause();
        }
    }
    
    @Override 
    public void addedToWorld() {
    	super.addedToWorld();
        calculateMotionDelay();
    }

    @Override
    public void die(){
    	((Level)(getWorld())).zombieDied();
        if (eatPlantSound.status.equals("play")) eatPlantSound.pause();
    }

    protected void calculateMotionDelay() {
    	motionCooldown = MOTION_CONSTANT / (level.getTileWidth() / secondsPerTile) * NANO_CONSTANT;
    }

}
