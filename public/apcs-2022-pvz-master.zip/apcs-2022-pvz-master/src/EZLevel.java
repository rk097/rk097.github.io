public class EZLevel extends Level {


    public EZLevel(Game game) {
        super(game);
    	bgm = new Audio("resources/music/battle1.wav");
    }

    @Override
    public void onDimensionsInitialized(){
        super.onDimensionsInitialized();
        GAME.getHUD().initializeDeck(PlantCard.PEASHOOTER, PlantCard.SUNFLOWER);
    }

    @Override
    void addZombies() {
    	zombiesLeft = 5;
		addZombie(0, new BasicZombie(1));
		addZombie(1, new BasicZombie(16));
		addZombie(2, new BasicZombie(24));
		addZombie(3, new BasicZombie(32));
		addZombie(2, new ConeZombie(60));
    }

}
