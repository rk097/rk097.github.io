import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * Name: Jiaming Liu // Ryan Kim
 * Period: 2
 **/

//--module-path "C:\Users\ryddk\OneDrive\Documents\Java\javafx-sdk-17.0.2\lib" --add-modules javafx.controls,javafx.fxml,javafx.media

public class Game extends Application {
	
	private HomeWindow homeScreen;
	private CardDeck HUD;
	private Level currentLevel;

	private class MouseEventHandler implements EventHandler<MouseEvent> {

		@Override
		public void handle(MouseEvent e) {
			if(!currentLevel.isGameRunning()) return;
			
			double x = e.getX();
			double y = e.getY();
			
			// handle suns on screen
			ArrayList<Sun> suns = (ArrayList<Sun>) currentLevel.getObjectsAt(x, y, Sun.class);
			if(suns.size() > 0) {
				Sun sun = suns.get(0);
				currentLevel.setSunAmount(currentLevel.getSunAmount() + sun.getSunValue());
				sun.play();
				currentLevel.remove(sun);
			} else {
				// handle planting
				int r = currentLevel.getRowForYPos(y);
				int c = currentLevel.getColForXPos(x);
				Plant p = HUD.getSelectedCardAsPlant();
				if(r != -1 && c != -1 && currentLevel.getPlant(r, c) == null && p != null) {
					if(e.getButton() == MouseButton.PRIMARY && currentLevel.getSunAmount() >= p.getPrice()) {
						currentLevel.addPlant(p, r, c);
						p.setX(currentLevel.getXPosForCol(c));
						p.setY(currentLevel.getYPosForRow(r));
						currentLevel.add(p);
						HUD.onCardSelected(null);
					} 
				}
			}
		}

	}

	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage window) throws Exception {
		homeScreen = new HomeWindow(this);
		homeScreen.show();
	}
	
	/*
	 * Key:
	 * 1 - First level (e.g. LawnLevel.)
	 */
	public void playLevel(int levelNumber) {
		if(levelNumber == 1) {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root);
			
			HUD = new CardDeck();
			
			currentLevel = new EZLevel(this);
			currentLevel.start();
			
			HUD.setSun(currentLevel.getSunAmount());
			currentLevel.getSunListeners().add(HUD);
			
			StackPane container = new StackPane(currentLevel, HUD);
			container.setOnMouseClicked(new MouseEventHandler());
			root.setCenter(container);
			
			homeScreen.setScene(scene);
		}
	}
    
	public CardDeck getHUD() {
		return HUD;
	}

	public void nextLevel() {
		homeScreen.nextLevel();
	}

	public void goHome() {
		homeScreen.reset();
	}
	
}
