import javafx.scene.image.Image;

public class BucketHeadZombie extends Zombie {
    public BucketHeadZombie(double enterDelay) {
    	super(enterDelay);
        health = 181 * 3;
        attackDamage = 100;
        defaultSprite = new Image("resources/bucketHead.gif");
        setImage(defaultSprite);
    }

    @Override
    public void takeDamage(int damage){
        super.takeDamage(damage);
        if (health <= 181){
            defaultSprite = new Image("resources/zombie.gif");
            setImage(defaultSprite);
        }
    }
}
