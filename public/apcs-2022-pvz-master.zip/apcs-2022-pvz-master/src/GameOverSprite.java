import engine.Actor;
import javafx.scene.image.Image;

public class GameOverSprite extends Actor {
	
	public GameOverSprite() {
		setImage(new Image("resources/gameOver.png"));
	}

	@Override
	public void act(long now) {
		
	}

}
