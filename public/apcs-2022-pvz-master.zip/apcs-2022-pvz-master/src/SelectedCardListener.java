
public interface SelectedCardListener {
	public void onCardSelected(PlantCard p);
}
