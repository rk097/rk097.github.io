
import engine.Actor;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;

public class Sun extends Actor {
	private Audio sound = new Audio("resources/music/sun.wav");
	private int sunValue;
	
	public Sun() {
        setImage(new Image("resources/sun.png"));
        setPreserveRatio(true);
        setFitWidth(32);
        
        sunValue = 25;
    }

	@Override
	public void act(long now) {
		
	}
	
	@Override
	public void addedToWorld() {
		
	}

	public void play() {
		sound.play();
	}
	
	public int getSunValue() {
		return sunValue;
	}

}
