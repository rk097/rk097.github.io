import javafx.scene.image.Image;

public class ConeZombie extends Zombie {
    public ConeZombie(double enterDelay) {
    	super(enterDelay);
        health = 181 * 2;
        attackDamage = 100;
        defaultSprite = new Image("resources/coneZombie.gif");
        setImage(defaultSprite);
    }

    @Override
    public void takeDamage(int damage){
        super.takeDamage(damage);
        if (health <= 181){
            defaultSprite = new Image("resources/zombie.gif");
            setImage(defaultSprite);
        }
    }
}
