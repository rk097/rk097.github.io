import java.io.IOException;
import java.util.ArrayList;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import engine.World;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;

public abstract class Level extends World {
	
	private boolean gameRunning;
	
	protected int zombiesLeft;
	protected int LAWN_ROWS, LAWN_COLUMNS, LAWN_WIDTH, LAWN_HEIGHT;
	protected int LAWN_OFFSET_X, LAWN_OFFSET_Y, TILE_WIDTH, TILE_HEIGHT;
	protected int STARTING_SUN;
	protected final int ZOMBIE_OFFSET = -5;
	protected Image LEVEL_BG;
	protected Game GAME;
	
	protected Plant lawnGrid[][];
	protected int sunAmount;
	
	private ArrayList<SunListener> sunListeners;

	private Audio deathSound = new Audio("resources/music/death.wav");
	protected Audio bgm;

	public Level(Game game) {
		setPrefWidth(1070);
        setPrefHeight(600);
        
        sunListeners = new ArrayList<>();
        this.GAME = game;
	}


	@Override
	public void onDimensionsInitialized() {
		LAWN_ROWS = 5;
		LAWN_COLUMNS = 9;
		LAWN_OFFSET_X = 250;
		LAWN_OFFSET_Y = 75;
		TILE_WIDTH = 82;
		TILE_HEIGHT = 100;
		LAWN_WIDTH = 1320;
		LAWN_HEIGHT = 870;
		LEVEL_BG = new Image("resources/bg.png");

		STARTING_SUN = 50;
		setSunAmount(STARTING_SUN);

		lawnGrid = new Plant[LAWN_ROWS][LAWN_COLUMNS];
		this.setBackground(new Background(new BackgroundImage(LEVEL_BG,
				BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT)));
		addZombies();
        this.gameRunning = true;

		bgm.play();
	}

	abstract void addZombies();
	
	@Override
	public void act(long now) {
		checkIfGameOver();
	}

	public void checkIfGameOver() {
		for(Zombie z : getZombies()) {
			if(z.getX() < LAWN_OFFSET_X/2) {
				onGameEnd(false);
				break;
			}
		}
		if(gameRunning && zombiesLeft == 0) {
			onGameEnd(true);
		}
	}

	private void onGameEnd(boolean won) {
		
		// ... end the game
		gameRunning = false;
		GAME.getHUD().remove();
		
		if(!won) {
			GameOverSprite gameLost = new GameOverSprite();
			gameLost.setX(getWidth()/2-gameLost.getWidth()/2);
			gameLost.setY(getHeight()/2-gameLost.getHeight()/2);
			add(gameLost);
			deathSound.play();
		} else {
			GAME.nextLevel();
		}
		
		// ... back to homescreen
		stopMusic();
		GAME.goHome();
		
		super.stop();
	}

	public void stopMusic() {
		try {
			bgm.stop();
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean addPlant(Plant p, int r, int c) {
		if(p == null) return false;
		if(!withinBounds(r, c)) return false;
		
		lawnGrid[r][c] = p;
		
		return true;
	}
	
	public Plant getPlant(int r, int c) {
		if(!withinBounds(r, c)) return null;
		return lawnGrid[r][c];
	}
	
	public ArrayList<Plant> getPlants() {
		return (ArrayList<Plant>) this.getObjects(Plant.class);
	}

	public int getRowOfPlant(Plant plant) {
		int r = 0;
		for(Plant[] lawnRow : lawnGrid) {
			for(Plant p : lawnRow) {
				if(p == plant) return r;
			}
			r++;
		}
		return -1;
	}
	
	public int getColOfPlant(Plant plant) {
		for(int j = 0; j < LAWN_COLUMNS; j++) {
			for(int i = 0; i < LAWN_ROWS; i++) {
				if(lawnGrid[i][j] == plant) return j;
			}
		}
		return -1;
	}
	
	public boolean addZombie(int r, Zombie z) {
		if(z == null) return false;
		if(!withinBounds(r, 0)) return false;
		
		z.setX(getWidth());
		z.setY(getYPosForRow(r)+ZOMBIE_OFFSET);
		z.setRow(r);
		add(z);
		
		return true;
	}
	
	public boolean addZombies(int r, Zombie... zombies) {
		if(zombies == null) return false;
		if(!withinBounds(r, 0)) return false;
		
		for(Zombie z : zombies) {
			z.setX(getWidth());
			z.setY(getYPosForRow(r)+ZOMBIE_OFFSET);
			z.setRow(r);
			add(z);
		}
		
		return true;
	}
	
	public ArrayList<Zombie> getZombies() {
		return (ArrayList<Zombie>) this.getObjects(Zombie.class);
	}
	
	public ArrayList<Zombie> getZombiesInRow(int r) {
		ArrayList<Zombie> al = new ArrayList<>();
		for(Zombie z : getZombies()) {
			if(getRowForYPos(z.getY()-ZOMBIE_OFFSET) == r) {
				al.add(z);
			}
		}
		return al;
	}

	protected boolean withinBounds(int r, int c) {
		return r >= 0 && r < LAWN_ROWS && c >= 0 && c < LAWN_COLUMNS;
	}
	
	/**
	 * Returns the x coordinate of the left edge of the given column.
	 * @param col the column
	 * @return the x coordinate of the left edge of the given column.
	 */
	public double getXPosForCol(int col) {
		return col * TILE_WIDTH + LAWN_OFFSET_X;
	}
	
	/**
	 * Returns the y coordinate of the top edge of the given row.
	 * @param row the row
	 * @return the y coordinate of the top edge of the given row.
	 */
	public double getYPosForRow(int row) {
		return row * TILE_HEIGHT + LAWN_OFFSET_Y;
	}
	
	/**
	 * Returns the column that contains the given x coordinate
	 * @param x the x coordinate
	 * @return the column that contains the given x coordinate
	 */
	public int getColForXPos(double x) {
		if(x < LAWN_OFFSET_X || x > LAWN_WIDTH + LAWN_OFFSET_X) return -1;
		return (int)((x - LAWN_OFFSET_X) / TILE_WIDTH);
	}
	
	/**
	 * Returns the row that contains the given y coordinate
	 * @param y the y coordinate
	 * @return the row that contains the given y coordinate
	 */
	public int getRowForYPos(double y) {
		if(y < LAWN_OFFSET_Y || y > LAWN_HEIGHT + LAWN_OFFSET_Y) return -1;
		return (int)((y - LAWN_OFFSET_Y) / TILE_HEIGHT);
	}

	public int getTileWidth() {
		return TILE_WIDTH;
	}

	public int getTileHeight() {
		return TILE_HEIGHT;
	}
	
	
	public int getSunAmount() {
		return sunAmount;
	}

	public void setSunAmount(int sunAmount) {
		for(SunListener s : sunListeners) s.onSunAmountChanged(sunAmount);
		this.sunAmount = sunAmount;
	}

	public ArrayList<SunListener> getSunListeners() {
		return sunListeners;
	}

	public boolean isGameRunning() {
		return gameRunning;
	}
	
	public void zombieDied() {
		zombiesLeft--;
	}

}
