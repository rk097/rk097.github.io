/**
 * Name: Jiaming Liu
 * Period: 2
 **/

public abstract class Plant extends NPC {
	
	// for plants, actionCooldown represents (in seconds) time between either attack or ability
	// cardCooldown is the delay (in seconds) of how much time must pass before the same plant can be planted again
	
    protected int price, cardCooldown, column;
    
    @Override
    public void addedToWorld() {
    	super.addedToWorld();
    	level.setSunAmount(level.getSunAmount() - price);
    	row = ((Level)(getWorld())).getRowOfPlant(this);
    	column = ((Level)(getWorld())).getColOfPlant(this);
    }
    
    public int getPrice() {
    	return price;
    }
}
