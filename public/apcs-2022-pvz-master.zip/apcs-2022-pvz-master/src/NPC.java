import engine.Actor;
import javafx.scene.image.Image;

public abstract class NPC extends Actor {
	
	protected int row;

	protected long NANO_CONSTANT = (long)1e9;
	protected long oldTime = 0;
	
	protected Level level;
	protected int health;
	protected double actionCooldown; // delay between each action, in seconds
	protected Image defaultSprite;
	
	public int getHealth() {
		return health;
	}

    public void takeDamage(int damage){
        health -= damage;
    	if(health <= 0) {
			this.die();
			level.remove(this);
		}
    }
	
	@Override
	public void addedToWorld() {
		level = (Level)getWorld();
	}

	public void die(){
		level.remove(this);
	}
    
    public void setRow(int r) {
    	row = r;
    }
    
    public int getRow() {
    	return row;
    }
}