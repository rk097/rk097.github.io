import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class HomeWindow extends Stage {
	
    private Audio bg = new Audio("resources/music/menu.wav");
    private Game game;
    private int currentLevelID = 1;
    
    public HomeWindow(Game game) {
        _HomeScreen root = new _HomeScreen(this);
        Scene scene = new Scene(root, 759, 480);
        setTitle("Plants vs. Zombies V1.0");
        setScene(scene);
        setResizable(false);
        bg.play();
        setOnCloseRequest(e -> bg.pause());
        this.game = game;
    }
    
    public Game getGame() {
    	return game;
    }
    
    public int getLevelID() {
    	return currentLevelID;
    }
    
    public void nextLevel() {
    	currentLevelID++;
    }
    
    public void playMusic() {
    	bg.play();
    }
    
    public void pauseMusic() {
    	bg.pause();
    }

	public void reset() {
		setScene(new Scene(new _HomeScreen(this), 759, 480));
		playMusic();
	}
}

class _HomeScreen extends VBox {
	
	private HomeWindow parent;
	
    public _HomeScreen(HomeWindow parent) {
    	
    	this.parent = parent;
    	
        BackgroundImage myBI = null;
        try {
            myBI = new BackgroundImage(new Image(new FileInputStream("resources/homeScreen.jpg")), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        setBackground(new Background(myBI));
        setWidth(759);
        setHeight(480);
        
        Group startBtnContainer = new Group();
        Image startBtnImg = null;
        try {
            startBtnImg = new Image(new FileInputStream("resources/startBtn.png"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        ImageView startBtnImgContainer = new ImageView(startBtnImg);
        
        Text dummy = new Text("");
        Text levelText = new Text(parent.getLevelID() + "-1");
        levelText.setFill(Color.WHITE);
        levelText.setFont(new Font("Eater-Regular", 16));
        
        startBtnContainer.getChildren().addAll(startBtnImgContainer, levelText, dummy);
        startBtnContainer.prefWidth(600);
        startBtnImgContainer.setLayoutX(395);
        startBtnImgContainer.setLayoutY(-14);
        levelText.setLayoutX(525);
        levelText.setLayoutY(35);
        startBtnContainer.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent e) {
				parent.pauseMusic();
				parent.getGame().playLevel(parent.getLevelID());
			}
        	
        });
        
        getChildren().add(startBtnContainer);
    }
}
